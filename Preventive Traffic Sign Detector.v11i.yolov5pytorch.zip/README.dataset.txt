# Preventive Traffic Sign Detector > 2024-05-18 12:07am
https://universe.roboflow.com/peruchon/preventive-traffic-sign-detector

Provided by a Roboflow user
License: CC BY 4.0

